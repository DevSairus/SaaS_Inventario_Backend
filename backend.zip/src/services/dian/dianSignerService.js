// backend/src/services/dian/dianSignerService.js
/**
 * Firma Digital XAdES-BES para Facturación Electrónica DIAN
 * 
 * Requiere: node-forge para manejo de certificados P12/PFX
 * npm install node-forge
 * 
 * La DIAN exige firma XAdES-BES con:
 * - Algoritmo: RSA-SHA256
 * - Canonicalización: C14N (xml-c14n-20010315)
 * - Política de firma: https://facturaelectronica.dian.gov.co/politicadefirma/v1/politicadefirmav2.pdf
 * - SHA256 de la política: dMoMvtcG5aIzgYo0tIsSQeVJBDnUnfSOfBpxXrmor0Y=
 */

const crypto = require('crypto');
const logger = require('../../config/logger');

const SIGNATURE_POLICY_ID = 'https://facturaelectronica.dian.gov.co/politicadefirma/v1/politicadefirmav2.pdf';
const SIGNATURE_POLICY_HASH = 'dMoMvtcG5aIzgYo0tIsSQeVJBDnUnfSOfBpxXrmor0Y=';

/**
 * Firma el XML de la factura con XAdES-BES usando certificado P12
 * @param {string} xmlContent - XML sin firmar
 * @param {object} opts
 * @param {string} opts.p12Base64 - Certificado P12 en base64
 * @param {string} opts.password - Contraseña del P12
 * @param {string} opts.invoiceNumber - Número de factura (para IDs únicos)
 * @returns {string} XML firmado
 */
async function signXml(xmlContent, { p12Base64, password, invoiceNumber }) {
  try {
    // Intentar cargar node-forge
    let forge;
    try {
      forge = require('node-forge');
    } catch (e) {
      logger.warn('[DIAN Signer] node-forge no está instalado. Instalando...');
      throw new Error('node-forge no está disponible. Ejecutar: npm install node-forge');
    }

    // Decodificar P12
    const p12Buffer = Buffer.from(p12Base64, 'base64');
    const p12Asn1 = forge.asn1.fromDer(p12Buffer.toString('binary'));
    const p12 = forge.pkcs12.pkcs12FromAsn1(p12Asn1, false, password);

    // Extraer clave privada y certificado
    let privateKey = null;
    let certificate = null;
    const certChain = [];

    for (const safeContent of p12.safeContents) {
      for (const safeBag of safeContent.safeBags) {
        if (safeBag.type === forge.pki.oids.certBag) {
          const cert = safeBag.cert;
          certChain.push(cert);
          if (!certificate) certificate = cert;
        } else if (safeBag.type === forge.pki.oids.pkcs8ShroudedKeyBag ||
                   safeBag.type === forge.pki.oids.keyBag) {
          privateKey = safeBag.key;
        }
      }
    }

    if (!privateKey || !certificate) {
      throw new Error('No se pudo extraer la clave privada o certificado del P12.');
    }

    // IDs únicos para los elementos de firma
    const sigId = generateSignatureId();
    const refId = `${sigId}-ref0`;
    const keyInfoId = `${sigId}-keyinfo`;
    const signedPropsId = `${sigId}-signedprops`;
    const sigValueId = `${sigId}-sigvalue`;

    // Obtener certificado en DER base64
    const certDer = forge.util.encode64(
      forge.asn1.toDer(forge.pki.certificateToAsn1(certificate)).getBytes()
    );

    // Digest del certificado (SHA-256)
    const certDerBytes = Buffer.from(
      forge.asn1.toDer(forge.pki.certificateToAsn1(certificate)).getBytes(), 'binary'
    );
    const certDigest = crypto.createHash('sha256').update(certDerBytes).digest('base64');

    // Información del emisor del certificado
    const issuerName = certificate.issuer.attributes
      .map(a => `${a.shortName}=${a.value}`)
      .join(',');
    const serialNumber = certificate.serialNumber;

    // Construir SignedProperties
    const signingTime = new Date().toISOString().replace('Z', '-05:00');
    const signedProperties = buildSignedProperties({
      sigId, signedPropsId, signingTime,
      certDigest, issuerName, serialNumber,
    });

    // Digest del documento completo (para ref0)
    // En producción se haría canonicalización C14N real
    const docDigest = crypto.createHash('sha256').update(xmlContent, 'utf8').digest('base64');

    // Digest de KeyInfo (placeholder — en producción se calcula del KeyInfo real)
    const keyInfoContent = buildKeyInfo(keyInfoId, certDer);
    const keyInfoDigest = crypto.createHash('sha256').update(keyInfoContent, 'utf8').digest('base64');

    // Digest de SignedProperties
    const signedPropsDigest = crypto.createHash('sha256').update(signedProperties, 'utf8').digest('base64');

    // Construir SignedInfo
    const signedInfo = buildSignedInfo({
      sigId, refId, keyInfoId, signedPropsId,
      docDigest, keyInfoDigest, signedPropsDigest,
    });

    // Firmar SignedInfo con RSA-SHA256
    const md = forge.md.sha256.create();
    md.update(signedInfo, 'utf8');
    const signatureBytes = privateKey.sign(md);
    const signatureBase64 = forge.util.encode64(signatureBytes);
    // Formatear en líneas de 76 chars
    const signatureFormatted = signatureBase64.match(/.{1,76}/g).join('\n');

    // Construir bloque Signature completo
    const signatureBlock = `<ds:Signature Id="${sigId}">
${signedInfo}
<ds:SignatureValue Id="${sigValueId}">
${signatureFormatted}
</ds:SignatureValue>
${keyInfoContent}
<ds:Object>
  <xades:QualifyingProperties Target="#${sigId}">
    ${signedProperties}
  </xades:QualifyingProperties>
</ds:Object>
</ds:Signature>`;

    // Insertar firma en el placeholder de UBLExtensions
    const signedXml = xmlContent.replace(
      '<ext:UBLExtension><ext:ExtensionContent/>',
      `<ext:UBLExtension><ext:ExtensionContent>${signatureBlock}`
    ).replace(
      '</ext:ExtensionContent></ext:UBLExtension>',
      '</ext:ExtensionContent></ext:UBLExtension>'
    );

    // Si no se pudo reemplazar el placeholder, agregar al final de UBLExtensions
    if (signedXml === xmlContent) {
      return xmlContent.replace(
        '</ext:UBLExtensions>',
        `  <ext:UBLExtension><ext:ExtensionContent>${signatureBlock}</ext:ExtensionContent></ext:UBLExtension>
</ext:UBLExtensions>`
      );
    }

    return signedXml;

  } catch (error) {
    logger.error('[DIAN Signer] Error firmando XML:', error.message);
    throw error;
  }
}

function generateSignatureId() {
  return `xmldsig-${crypto.randomUUID()}`;
}

function buildSignedInfo({ sigId, refId, keyInfoId, signedPropsId, docDigest, keyInfoDigest, signedPropsDigest }) {
  return `<ds:SignedInfo>
  <ds:CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>
  <ds:SignatureMethod Algorithm="http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"/>
  <ds:Reference Id="${refId}" URI="">
    <ds:Transforms>
      <ds:Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/>
    </ds:Transforms>
    <ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>
    <ds:DigestValue>${docDigest}</ds:DigestValue>
  </ds:Reference>
  <ds:Reference URI="#${keyInfoId}">
    <ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>
    <ds:DigestValue>${keyInfoDigest}</ds:DigestValue>
  </ds:Reference>
  <ds:Reference Type="http://uri.etsi.org/01903#SignedProperties" URI="#${signedPropsId}">
    <ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>
    <ds:DigestValue>${signedPropsDigest}</ds:DigestValue>
  </ds:Reference>
</ds:SignedInfo>`;
}

function buildKeyInfo(keyInfoId, certDer) {
  const certFormatted = certDer.match(/.{1,76}/g).join('\n');
  return `<ds:KeyInfo Id="${keyInfoId}">
  <ds:X509Data>
    <ds:X509Certificate>
${certFormatted}
    </ds:X509Certificate>
  </ds:X509Data>
</ds:KeyInfo>`;
}

function buildSignedProperties({ sigId, signedPropsId, signingTime, certDigest, issuerName, serialNumber }) {
  return `<xades:SignedProperties Id="${signedPropsId}">
  <xades:SignedSignatureProperties>
    <xades:SigningTime>${signingTime}</xades:SigningTime>
    <xades:SigningCertificate>
      <xades:Cert>
        <xades:CertDigest>
          <ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>
          <ds:DigestValue>${certDigest}</ds:DigestValue>
        </xades:CertDigest>
        <xades:IssuerSerial>
          <ds:X509IssuerName>${issuerName}</ds:X509IssuerName>
          <ds:X509SerialNumber>${serialNumber}</ds:X509SerialNumber>
        </xades:IssuerSerial>
      </xades:Cert>
    </xades:SigningCertificate>
    <xades:SignaturePolicyIdentifier>
      <xades:SignaturePolicyId>
        <xades:SigPolicyId>
          <xades:Identifier>${SIGNATURE_POLICY_ID}</xades:Identifier>
        </xades:SigPolicyId>
        <xades:SigPolicyHash>
          <ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>
          <ds:DigestValue>${SIGNATURE_POLICY_HASH}</ds:DigestValue>
        </xades:SigPolicyHash>
      </xades:SignaturePolicyId>
    </xades:SignaturePolicyIdentifier>
    <xades:SignerRole>
      <xades:ClaimedRoles>
        <xades:ClaimedRole>supplier</xades:ClaimedRole>
      </xades:ClaimedRoles>
    </xades:SignerRole>
  </xades:SignedSignatureProperties>
</xades:SignedProperties>`;
}

module.exports = { signXml };