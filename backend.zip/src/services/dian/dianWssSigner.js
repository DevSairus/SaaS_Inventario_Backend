/**
 * dianWssSigner.js — WS-Security X.509 con ExcC14N correcto
 * ═══════════════════════════════════════════════════════════
 * Usa un canonicalizador ExcC14N real que procesa el árbol XML
 * con contexto de ancestros, en lugar de strings manuales.
 *
 * REGLA ExcC14N (RFC 3741 / W3C):
 *   Un namespace se incluye en el canonical de un nodo E si:
 *   1. Es visiblemente utilizado por E o sus descendientes, Y
 *   2. No fue "rendered" (outputted) por ningún ancestro en el subset.
 *
 * Para WS-Security SOAP, el Envelope declara xmlns:soap, xmlns:a, xmlns:wsu.
 * Los elementos hijos (Action, To, Body, Timestamp) NO repiten esos NS
 * porque ya fueron rendered por el Envelope.
 */

'use strict';

const forge  = require('node-forge');
const crypto = require('crypto');

/* ── Namespaces ─────────────────────────────────────────── */
const NS = {
  SOAP:    'http://www.w3.org/2003/05/soap-envelope',
  ADDR:    'http://www.w3.org/2005/08/addressing',
  DS:      'http://www.w3.org/2000/09/xmldsig#',
  WSSE:    'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd',
  WSU:     'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd',
  WCF:     'http://wcf.dian.colombia/',
  X509VT:  'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-x509-token-profile-1.0#X509v3',
  B64ET:   'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary',
  EXC_C14N:'http://www.w3.org/2001/10/xml-exc-c14n#',
  SHA256:  'http://www.w3.org/2001/04/xmlenc#sha256',
  RSA_SHA256:'http://www.w3.org/2001/04/xmldsig-more#rsa-sha256',
};

/* ── Extraer cert/key del P12 ───────────────────────────── */
function extractFromP12(p12Base64, password) {
  const p12Der  = forge.util.decode64(p12Base64);
  const p12Asn1 = forge.asn1.fromDer(p12Der);
  const p12obj  = forge.pkcs12.pkcs12FromAsn1(p12Asn1, password);

  const keyBags = p12obj.getBags({ bagType: forge.pki.oids.pkcs8ShroudedKeyBag });
  const keyBag  = keyBags[forge.pki.oids.pkcs8ShroudedKeyBag]?.[0];
  if (!keyBag) throw new Error('No se encontró clave privada en el P12');

  const certBags = p12obj.getBags({ bagType: forge.pki.oids.certBag });
  const certs    = certBags[forge.pki.oids.certBag] || [];
  if (!certs.length) throw new Error('No se encontraron certificados en el P12');

  const entityCert = certs.find(b => {
    const bc = b.cert.getExtension('basicConstraints');
    return !bc || !bc.cA;
  }) || certs[0];

  const certPem    = forge.pki.certificateToPem(entityCert.cert);
  const keyPem     = forge.pki.privateKeyToPem(keyBag.key);
  const certDer    = forge.asn1.toDer(forge.pki.certificateToAsn1(entityCert.cert));
  const certBase64 = forge.util.encode64(certDer.getBytes());
  const subject    = entityCert.cert.subject.attributes
    .map(a => `${a.shortName || a.type}=${a.value}`).join(', ');

  return {
    certPem, keyPem,
    privateKey:  keyBag.key,
    certBase64,
    subject,
    notBefore:   entityCert.cert.validity.notBefore,
    notAfter:    entityCert.cert.validity.notAfter,
    serialHex:   entityCert.cert.serialNumber,
  };
}

/* ── ExcC14N correcto con contexto de ancestros ─────────── */
/**
 * Canonicaliza un fragmento XML usando ExcC14N,
 * dado el mapa de namespaces que ya fueron rendered por los ancestros.
 *
 * @param {string} elementXml   - El elemento a canonicalizar (string XML completo)
 * @param {Object} ancestorNS   - { prefix: uri } de los NS ya rendered por ancestros
 * @returns {string} canonical
 */
function excC14nWithContext(elementXml, ancestorNS = {}) {
  // Parsear el elemento para extraer: nombre, atributos, NS declarados, contenido
  // Usamos regex porque el XML es generado por nosotros (controlado, sin sorpresas)
  
  // Extraer tag de apertura
  const openTagMatch = elementXml.match(/^<([^\s>\/]+)((?:\s+[^>]*?)?)\s*>/s);
  if (!openTagMatch) throw new Error(`No se pudo parsear: ${elementXml.substring(0,100)}`);
  
  const fullTagName = openTagMatch[1]; // e.g. "soap:Body", "wsu:Timestamp", "a:Action"
  const attrsStr    = openTagMatch[2] || '';
  const innerClose  = elementXml.slice(openTagMatch[0].length, -(`</${fullTagName}>`).length);
  
  // Determinar prefijo del elemento
  const colonIdx = fullTagName.indexOf(':');
  const elemPrefix = colonIdx >= 0 ? fullTagName.substring(0, colonIdx) : '';
  
  // Parsear todos los atributos (incluyendo xmlns:*)
  const nsDeclared  = {}; // prefix→uri declarados en este elemento
  const regularAttrs = {}; // {prefix, localName, uri, value}
  
  const attrRegex = /\s+((?:xmlns(?::([^\s=]+))?|([^\s=:]+:)?([^\s=]+))\s*=\s*"([^"]*)")/g;
  let m;
  while ((m = attrRegex.exec(attrsStr)) !== null) {
    const full = m[1];
    if (full.startsWith('xmlns:')) {
      const prefix = m[2];
      const uri    = m[5];
      nsDeclared[prefix] = uri;
    } else if (full === `xmlns="${m[5]}"`) {
      nsDeclared[''] = m[5];
    } else {
      const attrPrefix = m[3] ? m[3].slice(0, -1) : '';
      const localName  = m[4];
      regularAttrs[`${attrPrefix}:${localName}`] = {
        prefix: attrPrefix, localName, value: m[5]
      };
    }
  }

  // Determinar el URI del elemento
  const elemUri = elemPrefix
    ? (nsDeclared[elemPrefix] || ancestorNS[elemPrefix] || '')
    : (nsDeclared[''] || ancestorNS[''] || '');

  // Recopilar todos los NS visiblemente utilizados por este elemento Y sus descendientes
  // Para simplificar (nuestro XML es conocido), recogemos los prefijos del elemento y attrs
  const usedPrefixes = new Set();
  if (elemPrefix) usedPrefixes.add(elemPrefix);
  for (const key of Object.keys(regularAttrs)) {
    const { prefix } = regularAttrs[key];
    if (prefix) usedPrefixes.add(prefix);
  }
  // También necesitamos los prefijos usados en el contenido interno
  const innerPrefixes = (innerClose.match(/(?:<|[\s])([a-zA-Z][a-zA-Z0-9]*):(?:[a-zA-Z])/g) || [])
    .map(s => s.replace(/^[<\s]/, '').replace(/:.*/, ''));
  for (const p of innerPrefixes) usedPrefixes.add(p);

  // ExcC14N: incluir NS si: visiblemente utilizado Y no ya rendered por ancestro
  const nsToRender = {};
  for (const prefix of usedPrefixes) {
    const uri = nsDeclared[prefix] || ancestorNS[prefix];
    if (!uri) continue;
    // ¿Ya fue rendered por un ancestro con el mismo valor?
    if (ancestorNS[prefix] === uri) continue; // ya rendered → no incluir
    nsToRender[prefix] = uri;
  }
  // También incluir redeclaraciones si el valor cambió (raramente ocurre aquí)
  for (const [prefix, uri] of Object.entries(nsDeclared)) {
    if (usedPrefixes.has(prefix) && ancestorNS[prefix] !== uri) {
      nsToRender[prefix] = uri;
    }
  }

  // Ordenar NS por URI (ExcC14N spec)
  const nsSorted = Object.entries(nsToRender).sort(([,a],[,b]) => a.localeCompare(b));

  // Ordenar atributos regulares: primero sin prefijo (por localName), luego con prefijo (por NS URI + localName)
  const attrsSorted = Object.values(regularAttrs).sort((a, b) => {
    const aUri = a.prefix ? (nsDeclared[a.prefix] || ancestorNS[a.prefix] || '') : '';
    const bUri = b.prefix ? (nsDeclared[b.prefix] || ancestorNS[b.prefix] || '') : '';
    if (!a.prefix && !b.prefix) return a.localName.localeCompare(b.localName);
    if (!a.prefix) return -1;
    if (!b.prefix) return 1;
    if (aUri !== bUri) return aUri.localeCompare(bUri);
    return a.localName.localeCompare(b.localName);
  });

  // Construir canonical del tag de apertura
  let canonical = `<${fullTagName}`;
  for (const [prefix, uri] of nsSorted) {
    canonical += ` xmlns:${prefix}="${uri}"`;
  }
  for (const attr of attrsSorted) {
    const attrName = attr.prefix ? `${attr.prefix}:${attr.localName}` : attr.localName;
    canonical += ` ${attrName}="${attr.value}"`;
  }
  canonical += `>${innerClose}</${fullTagName}>`;

  return canonical;
}

/* ── Context NS del documento SOAP ─────────────────────── */
// Los NS que el Envelope declara y que están en scope para todos los hijos
const ENVELOPE_NS = {
  'soap': NS.SOAP,
  'a':    NS.ADDR,
  'wsu':  NS.WSU,
};

// NS adicionales en scope dentro de wsse:Security
const SECURITY_NS = {
  ...ENVELOPE_NS,
  'wsse': NS.WSSE,
  // wsu ya está en ENVELOPE_NS; Security lo redeclara con mismo valor → no cambia
};

// NS adicionales en scope dentro de ds:Signature
const SIGNATURE_NS = {
  ...SECURITY_NS,
  'ds': NS.DS,
};

/* ── SHA256 base64 ──────────────────────────────────────── */
function sha256b64(s) {
  return crypto.createHash('sha256').update(s, 'utf8').digest('base64');
}

function fmtUtc(d) {
  return d.toISOString().replace(/\.\d+Z$/, 'Z');
}

/* ── Construir Reference ────────────────────────────────── */
function buildRef(id, digest) {
  return (
    `<ds:Reference URI="#${id}">` +
    `<ds:Transforms><ds:Transform Algorithm="${NS.EXC_C14N}"/></ds:Transforms>` +
    `<ds:DigestMethod Algorithm="${NS.SHA256}"/>` +
    `<ds:DigestValue>${digest}</ds:DigestValue>` +
    `</ds:Reference>`
  );
}

/* ── Constructor principal ──────────────────────────────── */
function buildSignedEnvelope({ action, endpoint, bodyContent, certBase64, privateKey }) {
  const bodyId   = 'Body-1';
  const tsId     = 'TS-1';
  const tokenId  = 'X509Token-1';
  const actionId = 'Action-1';
  const toId     = 'To-1';

  const now     = new Date();
  const expires = new Date(now.getTime() + 5 * 60 * 1000);
  const created = fmtUtc(now);
  const exp     = fmtUtc(expires);

  // ── Construir los 4 elementos tal como aparecerán en el XML final ──
  const actionXml = `<a:Action wsu:Id="${actionId}" soap:mustUnderstand="1">${action}</a:Action>`;
  const toXml     = `<a:To wsu:Id="${toId}" soap:mustUnderstand="1">${endpoint}</a:To>`;
  const tsXml     = (
    `<wsu:Timestamp wsu:Id="${tsId}">` +
    `<wsu:Created>${created}</wsu:Created>` +
    `<wsu:Expires>${exp}</wsu:Expires>` +
    `</wsu:Timestamp>`
  );
  const bodyXml   = `<soap:Body wsu:Id="${bodyId}">${bodyContent}</soap:Body>`;

  // ── Canonicalizar cada elemento con su contexto real de ancestros ──
  // a:Action y a:To: dentro de soap:Header, hijo directo del Envelope
  // Contexto: ENVELOPE_NS ya rendered
  const canonAction = excC14nWithContext(actionXml, ENVELOPE_NS);
  const canonTo     = excC14nWithContext(toXml,     ENVELOPE_NS);

  // wsu:Timestamp: dentro de wsse:Security (que está dentro de Header → Envelope)
  // Contexto: SECURITY_NS ya rendered
  const canonTS     = excC14nWithContext(tsXml,     SECURITY_NS);

  // soap:Body: hijo directo del Envelope
  // Contexto: ENVELOPE_NS ya rendered
  const canonBody   = excC14nWithContext(bodyXml,   ENVELOPE_NS);

  // ── Log de canonicals para debugging ──
  if (process.env.DEBUG_WSS) {
    console.log('[WSS] canonAction:', canonAction);
    console.log('[WSS] canonTo:    ', canonTo);
    console.log('[WSS] canonTS:    ', canonTS);
    console.log('[WSS] canonBody:  ', canonBody);
  }

  // ── Calcular digests ──
  const dAction = sha256b64(canonAction);
  const dTo     = sha256b64(canonTo);
  const dTS     = sha256b64(canonTS);
  const dBody   = sha256b64(canonBody);

  // ── Construir ds:SignedInfo ──
  // SignedInfo está dentro de ds:Signature que está dentro de Security(Envelope)
  // Contexto de SIGNATURE_NS ya rendered → SignedInfo no necesita declarar nada
  const signedInfo = (
    `<ds:SignedInfo>` +
    `<ds:CanonicalizationMethod Algorithm="${NS.EXC_C14N}"/>` +
    `<ds:SignatureMethod Algorithm="${NS.RSA_SHA256}"/>` +
    buildRef(actionId, dAction) +
    buildRef(toId,     dTo) +
    buildRef(tsId,     dTS) +
    buildRef(bodyId,   dBody) +
    `</ds:SignedInfo>`
  );

  // ── Canonicalizar SignedInfo para firmar ──
  // SignedInfo está en contexto SIGNATURE_NS (ds: ya rendered por ds:Signature)
  // ExcC14N: los hijos de SignedInfo solo usan ds: → ya rendered → canonical SIN xmlns
  // PERO: según XML-DSIG, el CanonicalizationMethod se aplica al nodo SignedInfo
  // en su contexto. Si WCF incluye xmlns de ancestros (soap, a, wsu, wsse, ds)
  // en la canonicalización del SignedInfo porque son "visiblemente utilizados"
  // por el subtree... en este caso NO lo son porque el subtree solo usa ds:.
  // ds: ya rendered → canonical = string sin xmlns adicionales
  const canonSignedInfo = excC14nWithContext(signedInfo, SIGNATURE_NS);

  if (process.env.DEBUG_WSS) {
    console.log('[WSS] canonSignedInfo:', canonSignedInfo);
  }

  // ── Firma RSA-SHA256 del SignedInfo canonicalizado ──
  const md = forge.md.sha256.create();
  md.update(canonSignedInfo, 'utf8');
  const sigB64 = forge.util.encode64(privateKey.sign(md));

  // ── Construir el envelope final ──
  return (
    `<?xml version="1.0" encoding="utf-8"?>` +
    `<soap:Envelope xmlns:soap="${NS.SOAP}" xmlns:a="${NS.ADDR}" xmlns:wsu="${NS.WSU}">` +
    `<soap:Header>` +
    `<a:Action wsu:Id="${actionId}" soap:mustUnderstand="1">${action}</a:Action>` +
    `<a:To wsu:Id="${toId}" soap:mustUnderstand="1">${endpoint}</a:To>` +
    `<wsse:Security xmlns:wsse="${NS.WSSE}" xmlns:wsu="${NS.WSU}" soap:mustUnderstand="1">` +
    `<wsu:Timestamp wsu:Id="${tsId}">` +
    `<wsu:Created>${created}</wsu:Created>` +
    `<wsu:Expires>${exp}</wsu:Expires>` +
    `</wsu:Timestamp>` +
    `<wsse:BinarySecurityToken wsu:Id="${tokenId}" EncodingType="${NS.B64ET}" ValueType="${NS.X509VT}">${certBase64}</wsse:BinarySecurityToken>` +
    `<ds:Signature xmlns:ds="${NS.DS}">` +
    signedInfo +
    `<ds:SignatureValue>${sigB64}</ds:SignatureValue>` +
    `<ds:KeyInfo>` +
    `<wsse:SecurityTokenReference xmlns:wsse="${NS.WSSE}">` +
    `<wsse:Reference URI="#${tokenId}" ValueType="${NS.X509VT}"/>` +
    `</wsse:SecurityTokenReference>` +
    `</ds:KeyInfo>` +
    `</ds:Signature>` +
    `</wsse:Security>` +
    `</soap:Header>` +
    `<soap:Body wsu:Id="${bodyId}">${bodyContent}</soap:Body>` +
    `</soap:Envelope>`
  );
}

module.exports = { extractFromP12, buildSignedEnvelope, NS };